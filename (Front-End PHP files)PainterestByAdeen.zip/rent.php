<html>
<body>

<?php

// Connect to the database
$conn = new mysqli('localhost', 'user', 'password', 'database');

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   // Retrieve the customer number and painting number from the form
   $cno = $_POST['customer_num'];
   $pno = $_POST['painting_num'];

   // Call the Rent_Painting procedure with the customer number and painting number as parameters
   $sql = "CALL rent_painting($cno,$pno)";
   $stmt = $conn->prepare($sql);
   $stmt->bind_param('ii', $cno, $pno);
   $stmt->execute();

   // Check for any errors
   if ($conn->error) {
      echo "Error: " . $conn->error;
   } else {
      echo "Successfully rented painting";
   }
}

?>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
   <label for="customer_num">Customer number:</label><br>
   <input type="text" id="customer_num" name="customer_num"><br>
   <label for="painting_num">Painting number:</label><br>
   <input type="text" id="painting_num" name="painting_num"><br><br>
   <input type="submit" value="Submit">
</form> 

</body>
</html>
